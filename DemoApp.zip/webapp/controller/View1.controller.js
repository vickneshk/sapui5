sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"jquery.sap.global"
	
], function(Controller,jQuery) {
	"use strict";

	return Controller.extend("gss.ui.demo.controller.View1", {
		onInit: function () {
				
				
				
		}
	
	});

});